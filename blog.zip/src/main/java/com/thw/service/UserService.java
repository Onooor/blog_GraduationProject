package com.thw.service;

import com.thw.po.User;


public interface UserService {

    User checkUser(String username, String password);
}
